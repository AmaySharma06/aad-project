"""
Experiments package for benchmarking algorithms.
"""
