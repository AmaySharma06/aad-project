"""
Traversal experiments.
"""
