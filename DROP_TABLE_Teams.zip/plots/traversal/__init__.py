# Traversal algorithm plots
