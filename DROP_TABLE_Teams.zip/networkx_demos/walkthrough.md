# NetworkX Implementation Demos and Comparison Walkthrough

This directory contains test scripts that run standard graph algorithms using the **NetworkX** library. These scripts have been updated to **mirror the exact experiments** found in the `experiments/` directory, ensuring a 1-to-1 comparison of results.

## Overview

We use our own graph generators (from `graph.graph_generator`) to create the input graphs. The parameters (graph sizes, densities, seeds, etc.) in these scripts match those in the corresponding `experiments/` scripts.

The following demos are available:

1.  **Centrality Algorithms** (`demo_centrality.py`)
    *   Mirrors `experiments/centrality/run_experiments.py`
    *   Tests PageRank runtime vs Size, Density, and Convergence.
2.  **Community Detection** (`demo_community.py`)
    *   Mirrors `experiments/community/run_experiments.py`
    *   Tests **Louvain** (NetworkX) and **Leiden** (via `leidenalg`) runtime and modularity vs Size, Quality (Planted Partition), and Density.
3.  **Traversal Algorithms** (`demo_traversal.py`)
    *   Mirrors `experiments/traversal/run_experiments.py`
    *   Tests BFS, DFS, and Connected Components runtime vs Size and Density.
4.  **Recommender Metrics** (`demo_recommender.py`)
    *   Mirrors `experiments/recommender/run_experiments.py`
    *   Tests Jaccard runtime vs Size; Recommendation Quality (Precision/Recall) vs Test Fraction; and Robustness to Noise.

## Prerequisites

Ensure you have the required libraries installed. Note that `leidenalg` and `igraph` are required for the Leiden algorithm comparison, as NetworkX does not implement it natively.

```bash
pip install networkx leidenalg igraph
```

## Running the Demos

You can run each demo script directly from the project root directory.

### 1. Centrality Algorithms

```bash
python networkx_demos/demo_centrality.py
```

**Comparison:**
Compare the output CSVs in `networkx_demos/results/` with `experiments/centrality/results/`.
- `pagerank_size_nx.csv` vs `pagerank_size.csv`
- `pagerank_density_nx.csv` vs `pagerank_density.csv`
- `pagerank_convergence_nx.csv` vs `pagerank_convergence.csv`

### 2. Community Detection

```bash
python networkx_demos/demo_community.py
```

**Comparison:**
Compare the output CSVs in `networkx_demos/results/` with `experiments/community/results/`.
- `community_size_nx.csv` vs `size_results.csv`
- `community_quality_nx.csv` vs `quality_results.csv`
- `community_density_nx.csv` vs `density_results.csv`

**Note:** The Leiden implementation uses `leidenalg` with `igraph`. The execution time includes the conversion from NetworkX to igraph to simulate the real-world cost of using this library in a Python environment.

### 3. Traversal Algorithms

```bash
python networkx_demos/demo_traversal.py
```

**Comparison:**
Compare the output CSVs in `networkx_demos/results/` with `experiments/traversal/results/`.
- `traversal_size_nx.csv` vs `size_results.csv`
- `traversal_density_nx.csv` vs `density_results.csv`

### 4. Recommender Metrics

```bash
python networkx_demos/demo_recommender.py
```

**Comparison:**
Compare the output CSVs in `networkx_demos/results/` with `experiments/recommender/results/`.
- `recommender_size_nx.csv` vs `size_results.csv`
- `recommender_quality_nx.csv` vs `quality_results.csv`
- `recommender_noise_nx.csv` vs `noise_results.csv`

## Comparison Strategy

1.  **Run the Custom Experiments:**
    ```bash
    python experiments/centrality/run_experiments.py
    python experiments/community/run_experiments.py
    python experiments/traversal/run_experiments.py
    python experiments/recommender/run_experiments.py
    ```
2.  **Run the NetworkX Demos:**
    ```bash
    python networkx_demos/demo_centrality.py
    python networkx_demos/demo_community.py
    python networkx_demos/demo_traversal.py
    python networkx_demos/demo_recommender.py
    ```
3.  **Analyze Results:**
    Open the generated CSV files side-by-side to compare execution times and quality metrics. Since the random seeds and parameters are identical, the graph structures will be the same, allowing for a direct performance comparison.
